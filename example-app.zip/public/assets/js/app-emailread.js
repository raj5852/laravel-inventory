$(function() {
	"use strict";

    new PerfectScrollbar('.email-navigation');
    new PerfectScrollbar('.email-read-box');


});