<!--start top header-->
<header class="top-header">
    <nav class="navbar navbar-expand gap-3">
        <div class="mobile-toggle-icon fs-3">
            <i class="bi bi-list"></i>
        </div>
        <div class="d-flex w-100 justify-content-center align-item-center">
        <img id="middleimage"  src="http://127.0.0.1:8000/assets/images/logo-icon.png" style="width: 50px">

        </div>
        <div class="top-navbar-right ms-auto">
            <a href="/logout">Logout</a>
        </div>
    </nav>
</header>
<!--end top header-->
