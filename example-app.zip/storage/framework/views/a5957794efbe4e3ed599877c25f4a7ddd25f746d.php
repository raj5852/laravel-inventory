<?php $__env->startSection('content'); ?>
    <!--start content-->
    <main class="page-content">
        <!--breadcrumb-->
        <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
            <div class="breadcrumb-title pe-3">Create Product Name</div>


        </div>
        <!--end breadcrumb-->
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-6">
                <div class="card card-body">
                    <form action="<?php echo e(route('creatporuct')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <label for="">Product Name</label>
                        <input required class="form-control" type="text" placeholder="Create Product Name" name="name"><br>
                        <input type="submit" value="Create" class="btn btn-primary">

                    </form>

                </div>
            </div>
        </div><br>
        <table class="table table-bordered">
            <thead>
                <tr>

                    <th>Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $productnames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$productname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td> <?php echo e($productname->name); ?> </td>
                    <td> <a href="pds/<?php echo e($productname->id); ?>" class="btn btn-danger">Delete</a> </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>
        <div class="d-flex justify-content-center">
            <?php echo $productnames->links(); ?>

        </div>

    </main>
    <!--end page main-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\example-app-admin-onedash\example-app\resources\views\createproduct.blade.php ENDPATH**/ ?>