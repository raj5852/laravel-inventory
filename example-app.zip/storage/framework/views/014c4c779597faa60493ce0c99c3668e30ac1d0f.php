<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--start content-->
    <main class="page-content">
        <!--breadcrumb-->
        <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">


        </div>
        <!--end breadcrumb-->

        <div class="card shadow-sm radius-10 border-0 mb-3">
            <div class="card-body">
                <h2 class="text-center">Delvery Report</h2>
                <hr>
                <form action="form-search">

                    <div class="d-flex justify-content-around">
                        <p>Name: <input class="form-control" name="name" type="name" placeholder="Search Name.."></p>
                        <p style="margin-left: 3px">Start Date: <input class="form-control" name="startdate" type="date"
                                id="datepicker1"></p>
                        <p style="margin-left: 3px">End Date: <input class="form-control " name="enddate" type="date"
                                id="datepicker2"></p>

                    </div>
                    <div style="margin-left: 80px">
                        <button type="submit" class="btn btn-primary">Search</button>

                    </div>


                </form>
                <br>

                <div class="table table-responsive">
                    <table class="table table-bordered yajra-datatable">
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Name</th>
                                <th>Total Weight</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e(++$i); ?> </td>
                                    <td> <?php echo e($data->name); ?> </td>
                                    <td> <?php echo e($data->weight); ?> </td>
                                    <td> <?php echo e($data->created_at); ?> </td>
                                    <td> <a href="view/<?php echo e($data->id); ?>" class="btn btn-success">View</a> </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <div class="d-flex justify-content-center">
                        <?php echo $datas->links(); ?>

                    </div>
                </div>
            </div>
        </div>

    </main>
    <!--end page main-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\example-app-admin-onedash\example-app\resources\views\admin.blade.php ENDPATH**/ ?>