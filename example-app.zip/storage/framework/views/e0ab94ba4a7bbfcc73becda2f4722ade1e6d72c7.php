<!DOCTYPE html>
<html lang="en">
<head>

    <title>QR</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"></head>
<body>
    <h3 style="text-align: center"><?php echo e($name); ?> </h3>
    <p style="text-align: center"> <?php echo e($address); ?> </p>
    <hr><hr>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>SL</th>
                <th>Name</th>
                <th>Weight</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e($key+1); ?> </td>
                <td> <?php echo e($product->productname); ?> </td>
                <td> <?php echo e($product->weight); ?> </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="2"  class="text-center"> Total </td>
                <td> <?php echo e($total); ?> </td>
            </tr>
        </tfoot>
    </table>
    <p> <b>Date and Time </b>: <?php echo e($dateandtime); ?> </p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\web\example-app-admin-onedash\example-app\resources\views\invoice.blade.php ENDPATH**/ ?>