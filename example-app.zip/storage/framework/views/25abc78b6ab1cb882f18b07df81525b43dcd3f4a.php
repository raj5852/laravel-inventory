<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--start content-->
    <main class="page-content">
        <!--breadcrumb-->
        <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">


        </div>
        <!--end breadcrumb-->

        <div class="card shadow-sm radius-10 border-0 mb-3">
            <div class="card-body">
                <h2 class="text-center">Customer Delvery Report</h2>
                <hr>

                <div class="table table-responsive">
                    <table class="table table-bordered yajra-datatable">
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Productname</th>
                                <th>Weigth</th>
                                <th>SIze</th>
                                <th>Date</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e(++$i); ?> </td>
                                <td> <?php echo e($data->productname); ?> </td>
                                <td> <?php echo e($data->weigth); ?> </td>
                                <td> <?php echo e($data->size); ?> </td>
                                <td> <?php echo e($data->created_at); ?> </td>

                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </div>

    </main>
    <!--end page main-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\example-app-admin-onedash\example-app\resources\views\view.blade.php ENDPATH**/ ?>