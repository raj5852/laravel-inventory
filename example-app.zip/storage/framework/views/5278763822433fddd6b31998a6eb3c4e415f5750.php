  <!--start sidebar -->
  <aside class="sidebar-wrapper" data-simplebar="true">
      <div class="sidebar-header">
          <div>
              <img src="<?php echo e(asset('assets/images/logo-icon1.png')); ?>" class="logo-icon" alt="logo icon">
          </div>
          <div>
              <h4 class="logo-text">MAQ PAPER</h4>
          </div>
          <div class="toggle-icon ms-auto"> <i class="bi bi-list"></i>
          </div>
      </div>
      <!--navigation-->
      <ul class="metismenu" id="menu">
          <?php if(request()->user()->hasAllPermissions(['stock'])): ?>
              <li>
                  <a href="<?php echo e(route('dashboard')); ?>">
                      <div class="parent-icon"><i class="bi bi-house-fill"></i>
                      </div>
                      <div class="menu-title">Dashboard</div>
                  </a>

              </li>
          <?php endif; ?>

          <?php if(request()->user()->hasAllPermissions(['product-input'])): ?>
              <li>
                  <a href="<?php echo e(route('productinput')); ?>">
                      <div class="parent-icon"><i class="bi bi-bag-check-fill"></i>
                      </div>
                      <div class="menu-title">Product Input</div>
                  </a>

              </li>
          <?php endif; ?>
          <?php if(request()->user()->hasAllPermissions(['product-output'])): ?>
              <li>
                  <a href="<?php echo e(route('productsale')); ?>">
                      <div class="parent-icon"><i class="bi bi-cart-check"></i>
                      </div>
                      <div class="menu-title">Product Output</div>
                  </a>

              </li>
          <?php endif; ?>
          <?php if(request()->user()->hasAllPermissions(['stock'])): ?>
              <li>
                  <a href="<?php echo e(route('stock')); ?>">
                      <div class="parent-icon"><i class="bi bi-flag-fill"></i>
                      </div>
                      <div class="menu-title">Stock</div>
                  </a>

              </li>
          <?php endif; ?>


      </ul>
      <!--end navigation-->
  </aside>
  <!--end sidebar -->
<?php /**PATH C:\xampp\htdocs\web\example-app-admin-onedash\example-app\resources\views\admin\sidebar.blade.php ENDPATH**/ ?>