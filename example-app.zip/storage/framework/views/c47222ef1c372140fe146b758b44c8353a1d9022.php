<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="assets/images/favicon-32x32.png" type="image/png" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!--plugins-->
    
    
    
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" />
    
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    <!-- loader-->
    <link href="<?php echo e(asset('assets/css/pace.min.css')); ?>" rel="stylesheet" />


    <!--Theme Styles-->
    
    
    
    
    <?php echo $__env->yieldContent('css'); ?>
    <title> Admin </title>
    <style>
        /* @media() */
        /* @media  screen and (min-width: 480px) { */

        @media  screen and (min-width: 780px) {
            #middleimage {
                display: none;
            }
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
<!-- Bootstrap bundle JS -->
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<!--plugins-->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/plugins/metismenu/js/metisMenu.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/pace.min.js')); ?>"></script>
<!--app-->
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('js'); ?>
<?php /**PATH C:\xampp\htdocs\web\example-app-admin-onedash\example-app\resources\views\admin\app.blade.php ENDPATH**/ ?>