<?php $__env->startSection('content'); ?>
    <!--start content-->
    <main class="page-content">
        <!--breadcrumb-->
        <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
            <div class="breadcrumb-title pe-3">Add product</div>


        </div>
        <hr>
        <!--end breadcrumb-->

        <div class="row">
            <div class="col-md-7">
                <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success')); ?>

                </div>

                <?php endif; ?>
                <div class="card card-body p-5">
                    <form action="/store" method="POST">
                        <?php echo csrf_field(); ?>
                        <label for="">Select Product</label>
                        <select required class="form-control" name="product" id="">

                            <?php $__currentLoopData = $productnames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($productname->name); ?>"><?php echo e($productname->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="">Size</label>
                        <input class="form-control" type="number" name="size" placeholder="Size-Inch" required>
                        <label for="">Weight</label>
                        <input class="form-control" type="number" name="weight" placeholder="Weight-KG" required><br>
                        <input type="submit" value="Save &amp; Print" class="btn btn-success">
                    </form>

                </div>
            </div>
        </div>


    </main>
    <!--end page main-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\example-app-admin-onedash\example-app\resources\views\productinput.blade.php ENDPATH**/ ?>