<!DOCTYPE html>
<html lang="en">

<head>

    <title>QR</title>
</head>

<body>
    <p style="text-align: center"><?php echo e($name); ?> </p>
    <p style="text-align: center"><?php echo e($size); ?> / <?php echo e($weight); ?> </p>
    <div class="text-align:center">
        <img style="text-align: center;margin-left:70px;margin-top:-20px"
            src="https://chart.googleapis.com/chart?cht=qr&chs=150x150&chl=<?php echo e($qrcode); ?>" alt="">
    </div>
    <p style="font-size: 13px; text-align:center"><?php echo e($qrcode); ?> </p>


    <p style="text-align: center"> <b>Date and Time :</b> <?php echo e($dateandtime); ?> </p>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\web\example-app-admin-onedash\example-app\resources\views\mypdf.blade.php ENDPATH**/ ?>