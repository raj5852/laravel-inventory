<!--start top header-->
<header class="top-header">
    <nav class="navbar navbar-expand gap-3">
        <div class="mobile-toggle-icon fs-3">
            <i class="bi bi-list"></i>
        </div>
        <div class="d-flex w-100 justify-content-center align-item-center">
        <img id="middleimage"  src="<?php echo e(asset('assets/images/logo-icon1.png')); ?>" style="width: 50px">

        </div>
        <div class="top-navbar-right ms-auto">
            <a href="/logout">Logout</a>
        </div>
    </nav>
</header>
<!--end top header-->
<?php /**PATH C:\xampp\htdocs\web\example-app-admin-onedash\example-app\resources\views\admin\header.blade.php ENDPATH**/ ?>